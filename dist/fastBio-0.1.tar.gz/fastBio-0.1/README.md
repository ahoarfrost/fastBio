# Welcome to fastBio

fastBio is a library for manipulating data and creating and training deep learning models for biological sequencing data. It is an extension of the fastai v1 library.

A number of pretrained models for biological sequencing data are available at the sister repository LookingGlass: https://github.com/ahoarfrost/LookingGlass

If you find fastBio useful, please cite the paper: